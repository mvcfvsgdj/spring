package com.sh.login.domain;

import lombok.Data;

@Data
public class HeatChartDTO {

   private String heat_code;
   private String user_code;
   private String user_heat;
   private String heat_date;
   private String check_heat;
   private String board_id;
}