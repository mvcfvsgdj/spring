package com.sh.address.domain;

import lombok.Data;

@Data
public class AddressDTO {

	private String member_post;
	private String member_addr;
	private String detailed_address;
}
