package com.sh.kakaologin.domain;

import lombok.Data;

@Data
public class KakaoUserDTO {
	private String user_kakao;
	private String nickname;
	private String profile_image;
}
