package com.sh.address.repository;

import com.sh.address.domain.AddressDTO;

public interface AddressRepositoryI {

	public int insert(AddressDTO addressDTO);

}